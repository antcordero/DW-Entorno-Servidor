<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MotorPro ERP</title>
    <link rel="stylesheet" href="assets/css/estilos.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap" rel="stylesheet">
</head>
<body>
    
    <header class="main-header">
        <div class="brand">
            <i class="fa-solid fa-car-side"></i> MOTOR PRO
        </div>
        <div class="user-info">
            <i class="fa-solid fa-user-tie"></i> Admin
        </div>
    </header>

    <div class="main-container">
        <?php include 'nav.php'; ?>
        
        <main class="content">