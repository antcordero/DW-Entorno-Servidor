</main> </div> <footer class="main-footer">
        <p>&copy; <?php echo date('Y'); ?> Motor Pro S.L. - Sistema de Gestión Interna</p>
    </footer>

</body>
</html>