<?php
/**
 * ARCHIVO DE CONFIGURACIÓN
 * Define las constantes globales para la conexión.
 * Ventaja: Si cambias la contraseña, solo la cambias aquí.
 */

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'concesionario');
define('MONEDA', '€'); // Configuración extra para la tienda
?>